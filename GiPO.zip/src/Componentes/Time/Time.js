import React from "react";
import './Time.css'


export default function Time(){
    return(
    <>
    <h2>Equipe de Desenvolvimento</h2>  
        <div className="time">

            <div className="dev">
                <img id="dev" src="./img/eduardo.png" alt="img eduardo"></img>
                <h4>Eduardo Ciclano</h4>
                <h5>Desenvolvedor</h5>
            </div>

            <div className="dev">
                <img id="dev" src="./img/henrique.jpeg" alt="img eduardo"></img>
                <h4>Luiz Nascimento</h4>
                <h5>Desenvolvedor</h5>
            </div>

            <div className="dev">
                <img id="dev" src="./img/eduardo.png" alt="img eduardo"></img>
                <h4>Eduardo Ciclano</h4>
                <h5>Desenvolvedor</h5>
            </div>

            <div className="dev">
                <img id="dev" src="./img/eduardo.png" alt="img eduardo"></img>
                <h4>Eduardo Ciclano</h4>
                <h5>Desenvolvedor</h5>
            </div>
        </div>

    </>
    )
}