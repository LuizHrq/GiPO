import React from "react";
import './HeaderQS.css';

export default function HeaderQS(){
    return(
        <>
            <header>
                <a href={"/"}><img id="logo" src="./img/logogipo1.png" alt="imagem logo"></img></a>
            </header>
        </>
    )
}