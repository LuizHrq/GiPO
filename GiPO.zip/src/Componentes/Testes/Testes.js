import React from "react";

import './Testes.css'

export default function Testes(){
    return(
        <>
        <section className="Testes">
            <h2>Teste seu conhecimento</h2>
            <br></br>
            
            <h4>Mediante os conteúdos abordados. responda: <br></br>O que é um IPO? </h4>
            <button type="submit">A - Abertura do capital de valores de uma companhia na bolsa de valores.</button>
            <button type="submit">B - Uma refeição.</button>
            <button type="submit">C - A declarção oficial de falência de uma companhia.</button>
            <button type="submit">D - Todas as alternativas estão corretas.</button>


        </section>
        </>
    )
}